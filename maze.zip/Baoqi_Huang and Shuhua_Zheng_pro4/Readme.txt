Creator: Shuhua Zheng(20289810) and Baoqi Huang(20231318)

1. Put Shuhua_zheng_Baoqi_Huang_prog4.cpp, mazeInfo.txt, background.bmp, mazeGraph.bmp in the same folder. 
2. Compile and run Shuhua_Zheng_Baoqi_Huang_prog4.cpp, the final maze graph will be saved in mazeGraph.bmp